#ifndef _SEM_H
#define _SEM_H

#include <linux/sched.h>

#define MAX_NAME 20

typedef struct sem_t{
	char name[MAX_NAME];
	int value;
	struct task_struct *wait_queue;
}sem_t;

#endif
