#ifndef _SHM_H
#define _SHM_H

#define SHM_SIZE 20

typedef struct{
	unsigned int key;
	unsigned int size;
	unsigned long page;
}shm_t;

#endif
