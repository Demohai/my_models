#include <linux/kernel.h>
#include <linux/sched.h>
#include <asm/segment.h>
#include <linux/fs.h>
#include <unistd.h>
#include <stdarg.h>
#include <stddef.h>
#include <errno.h>

char * proc_buf = NULL;
extern int vsprintf(char* buf, const char* fmt, va_list args);

int sprintf(char* buf, const char* fmt, ...)
{
	va_list args; 
	int i;
	va_start(args, fmt);
	i = vsprintf(buf, fmt, args);
	va_end(args);
	return i;
}

void get_psinfo()
{
	int read = 0;
	struct task_struct **p;
	if ((proc_buf = (char*)malloc(sizeof(char*)*1024)) == NULL) 
	{
		printk("psinfo - malloc error!\n");
		return -EINVAL;
	}

	read += sprintf(proc_buf + read, "%s", "pid\tstate\tfather\tcounter\tstart_time\n");
	for (p = &FIRST_TASK; p <= &LAST_TASK; p++)
	{
		if (*p != NULL)
		{
			read += sprintf(proc_buf + read, "%d\t", (*p)->pid);
			read += sprintf(proc_buf + read, "%d\t", (*p)->state);
			read += sprintf(proc_buf + read, "%d\t", (*p)->father);
			read += sprintf(proc_buf + read, "%d\t", (*p)->counter);
			read += sprintf(proc_buf + read, "%d\t", (*p)->start_time);
		}
	}
}

int proc_read(int dev, char* buf, int count, unsigned long* pos)
{
	int i;
	if (dev == 0) get_psinfo();
	/*if (!(*pos)) 
	{
	if (dev == 0) get_psinfo();
	}*/
	for (i = 0; i < count; i++)
	{
		/*if (proc_buf[i + *pos] == '\0') break; */
		put_fs_byte(proc_buf[i + (*pos)], buf + i + (*pos));
	}
	(*pos) += i;
	return i;
}
