#include <errno.h>
#include <linux/sched.h>
#include <linux/kernel.h>
#include <asm/segment.h>
#include <stdarg.h>
#include <stddef.h>
#include <linux/fs.h>

extern int vsprintf(char* buf, const char *fmt, va_list args);

int sprintf(char* buf, const char* fmt, ...)
{
	va_list args;
	int i;
	va_start(args, fmt);
	i = vsprintf(buf, fmt, args);
	va_end(args);
	return i;
}

int psinfo(unsigned long* pos, char* buf, int count)
{
	struct task_struct **p;
	int output_count = 0;
	char *psbuf = NULL;
	int chars = 0;
	int offset;
	offset = *pos;
	if ((psbuf=(char *)malloc(sizeof(char*)*1024)) == NULL)
	{
		printk("psinfo - malloc error!\n");
		return -EINVAL;
	}

	chars = sprintf(psbuf, "pid\tstate\tfather\tcounter\tstart_time\n");
	for (p = &LAST_TASK; p >= &FIRST_TASK; --p)
	{
		if (*p)
		{
			chars += sprintf(psbuf+chars, "%d\t%d\t%d\t%d\t%d\n", (*p)->pid, (*p)->state, (*p)->father, (*p)->counter, (*p)->start_time);
		}
	}
	*(psbuf+chars) = '\0';
	while (count > 0)
	{
		if (offset > chars) break;
		put_fs_byte(*(psbuf+offset), buf++);
		offset++;
		output_count++;
		count--;
	}
	(*pos) += output_count;
	free(psbuf);
	return output_count;
}

int proc_read(int dev, char* buf, int count, unsigned long* pos)
{
	if (dev == 0) return psinfo(pos, buf, count);
	return 0;
}
