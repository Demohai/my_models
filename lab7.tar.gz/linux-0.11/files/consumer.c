#define __LIBRARY__

#include <stdio.h>
#include <sem.h>
#include <stdlib.h>
#include <unistd.h>
#include <shm.h>

_syscall2(sem_t*, sem_open, const char*, name, unsigned int, value);
_syscall1(int, sem_wait, sem_t*, sem);
_syscall1(int, sem_post, sem_t*, sem);
_syscall1(int, sem_unlink, const char*, name);

_syscall2(int, shmget, unsigned int, key, size_t, size);
_syscall1(void*, shmat, int, shmid);


#define BUFSIZE 10
#define MAX_NUM 500

sem_t* Sem_open(const char *name, unsigned int value){
	sem_t* sem = sem_open(name, value);
	if (sem == NULL) {
		fprintf(stderr, "Error when create semaphore.\n");
		exit(1);
	}
	return sem;
}

int main(){
	int shmid;
	sem_t* empty;
	sem_t* full;
	sem_t* mutex;
	int *p;
	int data;
	int i;

	empty = Sem_open("empty", 0);
	full = Sem_open("full", 0);
	mutex = Sem_open("mutex", 0);

	/* fflush(stdout); */

	shmid = shmget(1024, BUFSIZE * sizeof(int));

	if (shmid == -1){
		fprintf(stderr, "shmget error.\n");
		exit(1);
	}

	p = (int *)shmat(shmid);
	for (i = 0; i < MAX_NUM; i++) {
		sem_wait(full);
		sem_wait(mutex);
		data = *(p + i % BUFSIZE);
		sem_post(mutex);
		sem_post(empty);
		printf("%d: %d\n", getpid(), data);
	}
	return 0;
}
