#define __LIBRARY__
#include <stdio.h>
#include <sem.h>
#include <fcntl.h>
#include <shm.h>
#include <unistd.h>
#include <stdlib.h>

_syscall2(sem_t*, sem_open, const char*, name, unsigned int, value);
_syscall1(int, sem_wait, sem_t*, sem);
_syscall1(int, sem_post, sem_t*, sem);
_syscall1(int, sem_unlink, const char*, name);

_syscall1(void*, shmat, int, shmid);
_syscall2(int, shmget, unsigned int, key, size_t, size);

#define BUFSIZE 10
#define MAX_NUM 500

int main(){
	sem_t* empty;
	sem_t* mutex;
	sem_t* full;
	int shmid;
	int *p;
	int i;

	sem_unlink("empty");
	sem_unlink("full");
	sem_unlink("mutex");

	empty = sem_open("empty", BUFSIZE);
	if (empty == NULL) {
		fprintf(stderr, "Error when create semaphore empty.\n");		
		exit(1);
	}

	full = sem_open("full", 0);
	if (full == NULL) {
		fprintf(stderr, "Error when create semaphore full.\n");
		exit(1);
	}
	mutex = sem_open("mutex", 1);
	if (mutex == NULL){
		fprintf(stderr, "Error when create semaphore mutex.\n");
		exit(1);
	}

	shmid = shmget(1024, BUFSIZE * sizeof(int));
	p = (int *)shmat(shmid);
	for (i = 0; i < MAX_NUM; i++) {
		sem_wait(empty);
		sem_wait(mutex);
		*(p + i % BUFSIZE) = i;
		sem_post(mutex);
		sem_post(full);
	}
	/* sem_unlink("empty");
	sem_unlink("full");
	sem_unlink("mutex"); */
	return 0;
}
