#include <string.h> // strcpy() strcmp()
#include <asm/segment.h> // get_fs_byte()
#include "../include/unistd.h" // NULL
#include <asm/system.h> // cli() sti()
#include "../include/linux/kernel.h" // printk()
#include <sem.h>

#define SEMS_SIZE 5

static sem_t sems[SEMS_SIZE] = {
	{"", 0, NULL},
	{"", 0, NULL},
	{"", 0, NULL},
	{"", 0, NULL},
	{"", 0, NULL}
};

sem_t* sys_sem_open(const char* name, unsigned int value){
	if (name == NULL){
		printk("name == NULL\n");
		return NULL;
	}
	int i, index = -1;
	char tmp_name[MAX_NAME];
	for (i = 0; i < MAX_NAME; i++) {
		tmp_name[i] = get_fs_byte(name + i);
		if (tmp_name[i] == '\0') break;
	}
	if (i == 0 || i == MAX_NAME) {
		printk("name too long or short, i = %d\n", i);
		return NULL;
	}
	for (i = 0; i < SEMS_SIZE; i++){
		if (strcmp(sems[i].name, "") == 0){
			index = index == -1 ? i: index;
			continue;	
		}
		if (strcmp(sems[i].name, tmp_name) == 0) return &sems[i];
	}

	sem_t *res = NULL;
	if (index != -1){
		res = &sems[index];
		for (i = 0; tmp_name[i] != '\0'; i++) sems[index].name[i] = tmp_name[i];
		sems[index].name[i] = '\0';
		res->value = value;
	}
	else
		printk("no empty slots: index = %d\n", index);
	return res;
}

int sys_sem_wait(sem_t* sem){
	if (sem == NULL || sem < sems || sem >= sems + SEMS_SIZE) return -1;
	cli();
	while (sem->value <= 0) sleep_on(&sem->wait_queue);
	sem->value--;
	sti();
	return 0;
}

int sys_sem_post(sem_t* sem){
	if (sem == NULL || sem < sems || sem >= sems + SEMS_SIZE) return -1;
	cli();
	wake_up(&sem->wait_queue);
	sem->value++;
	sti();
	return 0;
}

int sys_sem_unlink(const char* name){
	if (name == NULL) return -1;
	int i;
	char tmp_name[MAX_NAME];
	for (i = 0; i < MAX_NAME; i++){
		tmp_name[i] = get_fs_byte(name+i);
		if (tmp_name[i] == '\0') break;
	}

	if (i == 0 || i == MAX_NAME) return -1;
	tmp_name[i] = '\0';

	for (i = 0; i < SEMS_SIZE; i++){
		if (strcmp(sems[i].name, tmp_name)){
			sems[i].name[0] = '\0';
			sems[i].value = 0;
			sems[i].wait_queue = NULL;
			return 0;
		}
	}
	return -1;
}
