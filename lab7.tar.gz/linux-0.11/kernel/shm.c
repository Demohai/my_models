#include <shm.h>
#include <unistd.h>
#include <errno.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/mm.h>

/* #define SHM_SIZE 20
struct {
	unsigned int key;
	unsigned int size;
	unsigned long page;
}shm_list[SHM_SIZE];
*/
static shm_t shm_list[SHM_SIZE];

int sys_shmget(unsigned int key, size_t size) {
	int i;
	void *page;
	if (size > PAGE_SIZE) return -EINVAL;

	page = get_free_page(); /* get a free physical page */
	if (!page) return -ENOMEM;
	/*  This block is missing at first*/
	for (i = 0; i < SHM_SIZE; i++) {
		if (shm_list[i].key == key) return i;
	}

	for (i = 0; i < SHM_SIZE; i++) {
		if (shm_list[i].key == 0) {
			shm_list[i].key = key;
			shm_list[i].page = page;
			shm_list[i].size = size;
			return i;
		}
	}
	return -1;
}

void* sys_shmat(int shmid) {
	int i;
	void *addr;
	if (shmid < 0 || shmid > SHM_SIZE) return -EINVAL;

	addr = current->brk + get_base(current->ldt[1]);  /* get a free virtual address */
	/* addr = current->brk + current->start_code; */
	current->brk += PAGE_SIZE;
	if (shm_list[shmid].key != 0) {
		put_page(shm_list[shmid].page, addr); /* map the virtual address to physical address */
		incr_mem_map(shm_list[shmid].page);
		return (void*) current->brk - PAGE_SIZE;
	}
	return -EINVAL;
}
